
<?php
$con = mysqli_connect('127.0.0.1','root',"");
mysqli_select_db($con,'courier_db');
$sql = "DELETE from tbl_courier where cid='$_GET[cid]' ";
if(mysqli_query($con,$sql))
header("refresh:1; url=courier-list.php");
else
echo" not deleted";


?>




