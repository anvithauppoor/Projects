<?php
$name = $_POST['name'];
$email = $_POST['email'];
$card_number = $_POST['card_number'];
$month =$_POST['month'];
$year = $_POST['year'];
$cvc = $_POST['cvc'];
$conn = new mysqli('localhost' , 'root' , '' ,'courier_db');
if($conn->connect_error){
die('Connection Failed :  '.$conn->connect_error);
}
else
{
$stmt =  $conn->prepare("insert into pay(name,email,card_number,month,year,cvc)
values(?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssss",$name,$email,$card_number,$month,$year,$cvc);
$stmt->execute();
echo "Card is inserted successfully";
$stmt->close();
$conn->close();

}

?>
<html>
<head>
<script type="text/javascript" >
   function preventBack(){window.history.forward();}
    setTimeout("preventBack()", 0);
    window.onunload=function(){null};
</script>
</head>
<body>
</form>
<form method="get" action="disp.php">

 <center>   <button type="confirm"   value="confirm" style="height: 40px; width: 85px; left: 250; top: 250;">CONFIRM </button><center>
</form>
</body>
</html>