<?php
$con=mysqli_connect("localhost","root","","courier_db") or die(mysqli_error($con));
//$con=mysqli_connect("localhost","root","","courier_db") or die(mysqli_error($con));
?>
