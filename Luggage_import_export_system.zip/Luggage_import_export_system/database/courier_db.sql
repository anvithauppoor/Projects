-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2021 at 06:18 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `courier_db`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `gettbl_courier` (IN `id` INT)  select * from tbl_courier where id=cid$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Luggage` ()  NO SQL
select * from tbl_courier$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `cid` int(11) NOT NULL,
  `Luggage_id` int(11) NOT NULL,
  `action` varchar(20) NOT NULL,
  `cdate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`cid`, `Luggage_id`, `action`, `cdate`) VALUES
(1, 17, 'Inserted', '2019-12-06 17:46:38'),
(2, 18, 'Inserted', '2019-12-07 11:18:24'),
(3, 19, 'Inserted', '2021-01-11 16:46:48'),
(4, 20, 'Inserted', '2021-01-12 05:55:19'),
(5, 21, 'Inserted', '2021-01-12 12:49:37'),
(6, 22, 'Inserted', '2021-01-16 16:53:45'),
(7, 23, 'Inserted', '2021-01-16 16:57:39'),
(8, 24, 'Inserted', '2021-01-16 17:02:49'),
(9, 25, 'Inserted', '2021-01-16 17:07:07'),
(10, 26, 'Inserted', '2021-01-16 19:05:07'),
(11, 27, 'Inserted', '2021-01-19 09:22:17'),
(12, 28, 'Inserted', '2021-01-29 04:49:07'),
(13, 29, 'Inserted', '2021-01-29 11:02:08'),
(14, 30, 'Inserted', '2021-01-29 11:18:12');

-- --------------------------------------------------------

--
-- Table structure for table `pay`
--

CREATE TABLE `pay` (
  `name` varchar(200) NOT NULL,
  `email` varchar(200) CHARACTER SET latin1 NOT NULL,
  `card_number` int(200) NOT NULL,
  `month` int(200) NOT NULL,
  `year` int(200) NOT NULL,
  `cvc` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pay`
--

INSERT INTO `pay` (`name`, `email`, `card_number`, `month`, `year`, `cvc`) VALUES
('dadf', 'anvi@gmail.com', 2147483647, 10, 20, 6767),
('', '', 0, 8, 18, 0),
('', '', 0, 8, 18, 0),
('annappa', 'uppoorannappa@gmail.com', 2147483647, 10, 20, 567),
('anvitha', 'anvi@gmail.com', 2147483647, 12, 21, 798),
('', '', 0, 8, 18, 0),
('anvitha', 'ann@gmail.com', 2147483647, 10, 21, 789),
('an', 'anu@gmail.com', 5677989, 11, 26, 9898),
('anvitha', 'ann@gmail.com', 2147483647, 10, 25, 780),
('anvitha', 'ann@gmail.com', 7776, 9, 27, 67),
('anvitha', 'ann@gmail.com', 2147483647, 9, 24, 78),
('anvitha', 'ann@gmail.com', 2147483647, 14, 23, 677),
('anvitha', 'ann@gmail.com', 2147483647, 14, 23, 677),
('anvitha', 'ann@gmail.com', 2147483647, 14, 23, 677),
('anvitha', 'ann@gmail.com', 2147483647, 14, 23, 677),
('ram', 'ram@gmail.com', 2147483647, 16, 25, 679),
('anvitha', 'anu@gmail.com', 2147483647, 19, 24, 899),
('anvitha', 'ann@gmail.com', 2147483647, 15, 18, 788),
('anvitha', 'ann@gmail.com', 2147483647, 15, 18, 788),
('aryan', 'aryan@gamail.com', 2147483647, 12, 26, 677),
('anvitha23', 'esd@gmail.com', 2147483647, 9, 25, 677),
('anvi', 'ann@gmail.com', 2147483647, 15, 27, 767);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_courier`
--

CREATE TABLE `tbl_courier` (
  `cid` int(10) NOT NULL,
  `cons_no` varchar(20) NOT NULL,
  `ship_name` varchar(100) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `s_add` varchar(200) NOT NULL,
  `rev_name` varchar(100) NOT NULL,
  `r_phone` varchar(12) NOT NULL,
  `r_add` varchar(200) NOT NULL,
  `type` varchar(40) NOT NULL,
  `weight` double NOT NULL,
  `invice_no` varchar(20) NOT NULL,
  `qty` int(10) NOT NULL,
  `book_mode` varchar(20) NOT NULL,
  `freight` double NOT NULL,
  `mode` varchar(20) NOT NULL,
  `pick_date` varchar(20) NOT NULL,
  `pick_time` varchar(10) NOT NULL,
  `status` varchar(20) NOT NULL,
  `comments` varchar(250) NOT NULL,
  `book_date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_courier`
--

INSERT INTO `tbl_courier` (`cid`, `cons_no`, `ship_name`, `phone`, `s_add`, `rev_name`, `r_phone`, `r_add`, `type`, `weight`, `invice_no`, `qty`, `book_mode`, `freight`, `mode`, `pick_date`, `pick_time`, `status`, `comments`, `book_date`) VALUES
(21, 'QIVWH79T', 'anvitha', '98904367890', 'uppoor', 'geetha', '876798090922', 'udupi', 'Documents', 7, 'QIVWH79T', 6, 'ToPay', 1450, 'Train', '06/01/2021', '8am', 'In Transit', 'plzz', '2021-01-12'),
(20, 'RL22EZJL', 'anvitha', '98904367890', 'uppoor', 'geetha', '8767980909', 'udupi', 'Parcel', 9, '999999', 7, 'ToPay', 1450, 'Train', '06/01/2021', '7', 'Landed', 'please transfer in safe', '2021-01-12'),
(2, 'QIWWGIQP', 'Asif khan', '020 253623', 'shani peth', 'munna bhai', '020 88552', 'asdas das d', 'Documents', 20, '252525', 12, 'TBB', 240, 'Train', '29/01/2011', '4', 'Delivered', 'Plz deliver it', '2011-01-29'),
(3, 'Q906F73L', 'Amol sarode', '9532653652', 'metha nagar, bhusawal', 'sunil pal', '8585425412', 'balliram peth', 'Documents', 12, '239098', 12, 'ToPay', 200, 'Air', '26/01/2013', '4', 'Delivered', 'Thanks', '2011-01-29'),
(4, '2THBV8UM', 'Farzana Sk', '9532652365', 'xzyz', 'Asif Khan', '9852451254', 'ABC', 'Parcel', 2, '23788', 4, 'Paid', 90, 'Road', '20/01/2011', '12', 'Delivered', 'Plz transit', '2011-01-30'),
(16, 'F9IPYURX', 'ram', '75699800', 'canada', 'seetha', '89096789', 'corea', 'delicated_item', 8, '788998900', 6, 'ToPay', 1450, 'Train', '16/12/2019', '12:30', 'In Transit', 'plzz', '2019-12-01'),
(10, '4B44LJT1', 'yryt', 'hhr', 'hhr', 'jkk', '78990090', 'tht', 'Documents', 7, '78999009', 5, 'Paid', 800, 'Road', '04/11/2019', '18', 'In Transit', 'tey', '2019-11-30'),
(7, 'DWZZF581', 'yryt', 'hhr', 'hhj', 'yyy', '767798967', 'uppoor', 'delicated_item', 7, '6767878899', 9, 'Paid', 688, 'Air', '19/11/2019', '12:30', 'Delivered', 'plzz', '2019-11-24'),
(8, '3HC7LLOO', 'fg', '7879', ' ccg', 'jkk', '78990090', 'nnm', 'Parcel', 8, '78999009', 5, 'ToPay', 800, 'Train', '28/11/2019', '12:30', 'Completed', 'vff', '2019-11-24'),
(12, 'T58KUYED', 'yryt', '7879', 'jfhf', 'hfjj', '78990090', 'hjh', 'Documents', 7, '78999009', 5, 'Paid', 800, 'Air', '04/11/2019', '12:30', 'In Transit', 'gjg', '2019-11-30'),
(13, 'FW94FS3H', 'kk', 'hhr', 'gkkk', 'jkk', '78990090', 'jhj', 'Parcel', 7, '78999009', 5, 'ToPay', 800, 'Road', '04/11/2019', '12:30', 'In Transit', 'ggjcg', '2019-11-30'),
(14, 'UFU9R8MQ', 'geetha', '7889090934', 'udupi', 'annappa', '6779889909', 'kundapura', 'Parcel', 7, '75687', 5, 'ToPay', 789, 'Road', '14/11/2019', '12:30', 'Delayed', '78h', '2019-11-30'),
(22, 'UY6XGI6X', 'anvitha', '9890436789', 'udupi', 'ram', '69090', 'darwad', 'Documents', 89, 'UY6XGI6X', 89, 'TBB', 990, 'Road', '18/01/2021', '8am', 'In Transit', 'plzz', '2021-01-16'),
(23, 'UL77AWU3', 'anvitha', '9909799787', 'upoor', 'sfhjk', '8767988978', 'uppoor', 'Documents', 9, 'UL77AWU3', 6, 'TBB', 1450, 'Air', '05/01/2021', '8am', 'In Transit', 'fast', '2021-01-16'),
(24, 'OS39GYW6', 'anvitha', '9909799787', 'upoor', 'sfhjk', '8767988978', 'uppoor', 'Documents', 9, 'UL77AWU3', 6, 'TBB', 1450, 'Air', '', '8am', 'In Transit', 'fast', '2021-01-16'),
(25, 'D5C6R652', 'deepak', '7894563216', 'karkala', 'reetu', '8767988978', 'bangalore', 'Documents', 9, 'D5C6R652', 7, 'ToPay', 990, 'Train', '17/01/2021', '8am', 'In Transit', 'be fast', '2021-01-16'),
(26, 'VDIOKWOS', 'rita', '9890436789', 'tamilnadu', 'Gagan', '6799888888', 'karwar', 'Documents', 6, 'VDIOKWOS', 7, 'ToPay', 990, 'Road', '19/01/2021', '8am', 'In Transit', 'good', '2021-01-16'),
(27, 'XYE1WOLE', 'anvitha', '6778986778', 'udupi', 'geetha', '7898096778', 'karwar', 'Documents', 7, 'UY6XGI6X', 7, 'ToPay', 1450, 'Road', '11/01/2021', '5am', 'In Transit', 'plzz', '2021-01-19'),
(28, '1Z51RBZQ', 'ganesh', '7899009007', 'canada', 'aryan', '6899890000', 'udupi', 'Parcel', 5, '1Z51RBZQ', 8, 'ToPay', 1450, 'Road', '18/01/2021', '8am', 'In Transit', 'plzz be fast', '2021-01-29'),
(29, 'N0CAY81G', 'anvitha', '9890436789', 'uppoor', 'geetha', '8767988978', 'mangalore', 'Parcel', 9, 'N0CAY81G', 7, 'ToPay', 990, 'Road', '11/01/2021', '8am', 'In Transit', 'plzz', '2021-01-29'),
(30, 'H09OJYH4', 'anvitha', '9890436789', 'mangalore', 'geetha', '8767988978', 'uppoor', 'Parcel', 9, 'H09OJYH4', 7, 'ToPay', 1540, 'Train', '04/01/2021', '8am', 'In Transit', 'plz', '2021-01-29');

--
-- Triggers `tbl_courier`
--
DELIMITER $$
CREATE TRIGGER `insertLog` AFTER INSERT ON `tbl_courier` FOR EACH ROW insert into logs values(null,NEW.cid, 'Inserted', Now())
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_courier_officers`
--

CREATE TABLE `tbl_courier_officers` (
  `cid` int(10) NOT NULL,
  `officer_name` varchar(40) NOT NULL,
  `off_pwd` varchar(40) NOT NULL,
  `address` varchar(250) NOT NULL,
  `email` varchar(100) NOT NULL,
  `ph_no` varchar(12) NOT NULL,
  `office` varchar(100) NOT NULL,
  `reg_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_courier_officers`
--

INSERT INTO `tbl_courier_officers` (`cid`, `officer_name`, `off_pwd`, `address`, `email`, `ph_no`, `office`, `reg_date`) VALUES
(1, 'kapil', 'kapil', 'asif nagar , hyderabad', 'kapil@gmail.com', '9890989989', 'Fast Courier - Jalgaon', '2011-01-30 09:25:21'),
(2, 'Ashraf Sk.', 'ashraf', '11, bhaguday nagar', 'ashraf@gmail.com', '9854254125', 'Fast Courier - Aurangabad', '2011-01-30 09:40:42'),
(3, 'sunil', 'sunil', '390, sani peth', 'sunil@gmail.com', '9890989989', 'Fast Courier - Pune', '2011-01-30 17:50:34');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_courier_track`
--

CREATE TABLE `tbl_courier_track` (
  `id` int(10) NOT NULL,
  `cid` int(10) NOT NULL,
  `cons_no` varchar(20) NOT NULL,
  `current_city` varchar(100) NOT NULL,
  `status` varchar(30) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `bk_time` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_courier_track`
--

INSERT INTO `tbl_courier_track` (`id`, `cid`, `cons_no`, `current_city`, `status`, `comments`, `bk_time`) VALUES
(1, 1, 'M22P7KHM', 'Fast Courier - Jalgaon', 'Delayed', 'Delay due to rain', '2011-01-30 10:23:04'),
(3, 1, 'M22P7KHM', 'Fast Courier - Jalgaon', 'Delayed', 'Delayed due to rain', '2011-01-30 10:26:43'),
(4, 4, '2THBV8UM', 'Fast Courier - Aurangabad', 'Delayed', 'Due to rain', '2011-01-30 17:44:52'),
(5, 1, 'M22P7KHM', 'Fast Courier - Jalgaon', 'Completed', 'Completed', '2011-01-30 17:49:11'),
(6, 5, 'WNFNQ58I', 'Fast Courier - Jalgaon', 'Onhold', '', '2019-11-19 21:16:07'),
(7, 5, 'WNFNQ58I', '', 'Landed', '', '2019-11-22 19:39:06'),
(8, 8, '3HC7LLOO', '', 'Landed', '', '2019-11-24 13:13:16'),
(9, 8, '3HC7LLOO', '', 'Completed', '', '2019-11-24 13:16:27'),
(10, 14, 'UFU9R8MQ', '', 'Delayed', '', '2019-12-01 11:29:15'),
(11, 20, 'RL22EZJL', '', 'Landed', 'good', '2021-01-12 12:43:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_offices`
--

CREATE TABLE `tbl_offices` (
  `id` int(10) NOT NULL,
  `off_name` varchar(100) NOT NULL,
  `address` varchar(230) NOT NULL,
  `city` varchar(100) NOT NULL,
  `ph_no` varchar(20) NOT NULL,
  `office_time` varchar(100) NOT NULL,
  `contact_person` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_offices`
--

INSERT INTO `tbl_offices` (`id`, `off_name`, `address`, `city`, `ph_no`, `office_time`, `contact_person`) VALUES
(1, 'Fast Courier - Jalgaon', '290, shani peth, jalgaon', 'Jalgaon', '0257-25125', '10.00 am - 9.00 pm', 'Shammi Kapur'),
(2, 'Fast Courier - Aurangabad', '20/12, sector 12, bhavani peth', 'Aurangabad', '0245-858521', '10.00 am - 9.00 pm', 'Amol Patil'),
(3, 'Fast Courier - Pune', '230, Fashion Street', 'pune', '020-25125', '10.00 am - 9.00 pm', 'Atul Nigade');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `contact`, `city`, `address`) VALUES
(0, 'anvi', 'anvi@gmail.com', 'c1348c49a9350b80477ecbcd25c4f301', '8900948756', 'udupi', 'uppoor'),
(0, 'anu', 'uppoorannappa@gmail.com', 'b3b253c6ea78ef812554fef1a9ed8806', '47907899', 'ghhj', 'hjk'),
(0, 'anu', 'anu@gmail.com', 'cc54de3876b865a9fb0267f3cb85ad5c', '47907899', 'uppor', 'uppoor'),
(0, 'anvitha', 'ann@gmail.com', 'b3b253c6ea78ef812554fef1a9ed8806', '57898909', 'udupi', 'udupi'),
(0, 'aa', 'aa@ss.dd', '9db06bcff9248837f86d1a6bcf41c9e7', 'aa', '2222', '22'),
(0, 'anvitha', 'r@gmail.com', '14e1b600b1fd579f47433b88e8d85291', '9765467697', 'udupi', 'upoor'),
(0, 'Ramesh', 'ramesh@gmail.com', '550e1bafe077ff0b0b67f4e32f29d751', '9765467697', 'mangalore', 'mangalore');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `tbl_courier`
--
ALTER TABLE `tbl_courier`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `tbl_courier_officers`
--
ALTER TABLE `tbl_courier_officers`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `tbl_courier_track`
--
ALTER TABLE `tbl_courier_track`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_offices`
--
ALTER TABLE `tbl_offices`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_courier`
--
ALTER TABLE `tbl_courier`
  MODIFY `cid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tbl_courier_officers`
--
ALTER TABLE `tbl_courier_officers`
  MODIFY `cid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_courier_track`
--
ALTER TABLE `tbl_courier_track`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_offices`
--
ALTER TABLE `tbl_offices`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
