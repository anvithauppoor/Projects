<nav class="navbar navbar-inverse navabar-fixed-top">
 
              <div class="container">
 
                  <div class="navbar-header">
      
                 <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
         
                  <span class="icon-bar"></span>
         
                  <span class="icon-bar"></span>
               
            <span class="icon-bar"></span>
<span class="icon-bar"></span>
    
 <span class="icon-bar"></span>
<span class="icon-bar"></span>
                
       </button>
            
           <a href="index.php" class="navbar-brand">Luggage Import-Export System</a>
                   </div>
        
           
                   <div class="collapse navbar-collapse" id="myNavbar">
   
                    <ul class="nav navbar-nav navbar-right">
           
                <?php
            if(isset($_SESSION['email'])){
                           ?>
     
                      <li><a href="add-courier.php"><span class="glyphicon glyphicon-shopping-cart"></span> Add_Luggage</a></li>
   
                        <li><a href="settings1.php">
<span class="glyphicon glyphicon-cog">
</span> Settings</a></li>
    <li><a href="track-status.php">
<span class="glyphicon glyphicon">
</span> Track_Luggage</a></li>
                        <li><a href="logout1.php">
<span class="glyphicon glyphicon-log-out">
</span> Logout</a></li>
     
                      <?php
                           }else{
                            ?>
                
            <li><a href="signup1.php"><span class="glyphicon glyphicon-user">
</span> Sign Up</a></li>
       
                    <li><a href="login1.php"><span class="glyphicon glyphicon-log-in">
</span> Login</a></li>
             
              <?php
                           }
                           ?>
                           
                       </ul>
          
         </div>
        
       </div>

</nav>