<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
              <table border="0" align="center" width="90%">
                <tbody><tr bgcolor="#EFF7FC">
                  <td class="aalpha" bgcolor="#EFF7FC" height="19"><div align="center">
                      <p><strong> Status Check </strong>:</p>
                  </div></td>
                </tr>
                <tr bgcolor="#EFF7FC">
                  <td class="aalpha" bgcolor="#FFFFFF" height="19"><div align="center"><a href="track-status.php" target="_self">Click Here </a> </div></td>
                </tr>
                 </tbody></table>


<table border="0" align="center" width="90%">
                <tbody><tr bgcolor="#EFF7FC">
                  <td class="aalpha" bgcolor="#EFF7FC" height="19"><div align="center">
                      <p><strong> Add Luggage </strong>:</p>
                  </div></td>
                </tr>
                <tr bgcolor="#EFF7FC">
                  <td class="aalpha" bgcolor="#FFFFFF" height="19"><div align="center"><a href="add-courier.php" target="_self">Click Here </a> </div></td>
                </tr>
                 </tbody></table>
       
       
</head></html>