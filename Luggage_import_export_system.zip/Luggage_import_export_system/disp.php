<?php
    session_start();
   ?>
<!DOCTYPE html>
<html>
    <head>
<script type="text/javascript" >
   function preventBack(){window.history.forward();}
    setTimeout("preventBack()", 0);
    window.onunload=function(){null};
</script>

        <link rel="shortcut icon" href="img/lifestyleStore.png" />
        <title>Projectworlds Store</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="css/style2.css" type="text/css">
    </head>
    <body>
        <div>
            <?php
                require 'header1.php';
            ?>
  


<p>  </p>
<p> </p>
<head>
<style>
.center {
margin: auto;
width: 50%;
border: 3px solid green;
padding: 10px;
}
</style>
</head>
<body>

<div class="center">
<p> <b>your Luggage Transportation has been confirmed.</b> </p>
<p><b>THANK YOU FOR USING LUGGAGE IMPORT-EXPORT SYSTEM.</b></p>
<p><b>VISIT AGAIN............</b></p>
</div>
<p>     </p>

</body>
</html>