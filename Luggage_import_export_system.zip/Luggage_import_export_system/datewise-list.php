
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Admin</title>
<link href="css/mystyle.css" rel="stylesheet" type="text/css">
<link href="css/style.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style2 {color: #FFFFFF}
-->
</style>
</head>
<body>
<table border="0" cellpadding="0" cellspacing="0" align="center" width="900">
  <tbody><tr>
    <td width="900">
<?php include("header.php"); ?>
	

<!DOCTYPE html>
<html>

<head>

<title>Table with database</title>
<script type="text/javascript" >
   function preventBack(){window.history.forward();}
    setTimeout("preventBack()", 0);
    window.onunload=function(){null};
</script>
<style>
table {
border-collapse: collapse;
width: 100%;
color: #0000FF;
font-family: monospace;
font-size: 25px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: #ooooFF}
</style>
</head>
<body>
<table>
<tr>
<th>Id</th>
<th>Luggage_no</th>
<th>Date   and   Time</th>
</tr>

<?php
$conn = mysqli_connect ("localhost","root","","courier_db");

$sql = "SELECT cid, Luggage_id,  cdate FROM logs";
if($result=mysqli_query($conn, $sql)){
while($row=mysqli_fetch_assoc($result))
{
echo "<tr><td>" . $row["cid"]. "</td><td>" . $row["Luggage_id"] . "</td><td>"
. $row["cdate"]. "</td></tr>";

}
}
?>
</table>
</body>
<br><center><form method="get" action="admin.php">
    <button type="back"   value="back"  style="height: 30px;background-color;     width: 85px; left: 250; top: 250;">go_back  </button>
</form></center></br>
</html>



  
  
 