<?php
session_start();
?> 

<!DOCTYPE html>

<html>
  
  <head>
      
    
     <link rel="shortcut icon" href="img/lifestyleStore.png" />
 
       <title>Luggage Import-Export System</title>
    
    <meta charset="UTF-8">
   
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- latest compiled and minified CSS -->
  
      <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
     
   <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js">
</script>
        
<!-- Latest compiled and minified javascript -->
   
     <script type="text/javascript" src="bootstrap/js/bootstrap.min.js">
</script>
   
     <!-- External CSS -->
 
       <link rel="stylesheet" href="css/style2.css" type="text/css">
 
   </head>
 
   <body>
   
     <div>
       
    <?php
            require 'header1.php';
           ?>
     
      <div id="bannerImage">
           
    <div class="container">
          
         <center>
                
   <div id="bannerContent">
          
             <h1>WELCOME</h1>
     
                  <p>Safe Import-Export  of Luggage</p>
   
                                    </div>
       
            </center>
   
  <form method="get" action="buttons.html">
    <button type="back"   value="back"  style="height: 30px;background-color:black;     width: 85px; left: 250; top: 250;">go_back  </button>
</form>   
            </div>
   
    
        </div>
    <style>
body {
background-image:url("nnn.jpg");
}
</style>
     
    </body> 

</html>